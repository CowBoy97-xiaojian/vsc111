package com.hoolai.bi.core;
/**
 *
 *@description: 
 *@author: Ksssss(chenlin@hoolai.com)
 *@time: 2019-11-26 22:49
 * 
 */
 
public class SyncRealTimeData {
}
